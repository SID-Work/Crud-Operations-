const mongoose = require('mongoose');
// defining schema and models

const userSchema = new mongoose.Schema({
  firstname: {
    type: String,
    required: true
  },
  lastname: {
    type: String,
    required: true
  },
  email: {
    type: String,
    required: true,
    unique: true
  },
  profilePic: {
    type: String
  }
});

const User = mongoose.model('User', userSchema);

module.exports = User;
