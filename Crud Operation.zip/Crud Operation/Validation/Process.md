We required node_module file for istall dependencies.
run command in terminal- npm install

Ensure That mongodb is running locally on your pc and connect with your server

Now, Its time to start server
command - node server.js
note: ther server will start on "http://localhost:3000

Crud operations:

Post:
   1) Go to browser and run command - localhost:3000.
   2) Fill all the info and hit create user. 
   3) If you see alert message ('user created'), The user information is successfully store on server.

 Get, Put and Delete:
   1) To perform this operations you need to use tools like "postman".

   2) In request section select operation you wants to perform & then paste the following link in Enter url section -
      url - "http://localhost:3000/api/users/{userid}"




Following all this steps we able to perform Crud oprations with validation Using node js framework- Express.js


Thank You!