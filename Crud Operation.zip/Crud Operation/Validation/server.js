const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const multer = require('multer');
const cors = require('cors');
const fs = require('fs');

const app = express();
const PORT = 3000;

// Connecting to teh mongodb
mongoose.connect('mongodb://localhost:27017/usercreations')
  .then(() => console.log('MongoDB connected'))
  .catch((err) => console.log('Failed to connect to MongoDB', err));

// Define a User Schema using Mongoose
const userSchema = new mongoose.Schema({
  firstname: { type: String, required: true },
  lastname: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  profilePic: { type: String }
});

// Model Which is collection of Schemas
const User = mongoose.model('User', userSchema); 

// Middleware to parse incoming requests
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors()); // Enable CORS

// Ensure uploads directory exists
const uploadDir = './uploads';
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir);
}

// Multer helps to upload files to the server
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, './uploads');
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' + file.originalname);
  }
});
const upload = multer({ storage: storage });

// Serve static files from the 'public' and 'uploads' folder(Middlewares)
app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Create user (POST request)
app.post('/api/users', upload.single('profilePic'), async (req, res) => {
  const { firstname, lastname, email } = req.body;

  // validation as mensioned in Question
  if (!firstname || !lastname || !email) {
    return res.status(400).json({ message: 'All fields are required' });
  }

  // Process of saving user to the mongodb
  try {
    const newUser = new User({
      firstname,
      lastname,
      email,
      profilePic: req.file ? req.file.filename : null,
    });

    const savedUser = await newUser.save();
    res.status(201).json(savedUser);
  } catch (err) {
    if (err.code === 11000) { // This code is helps to handle dupblicate email error
      return res.status(400).json({ message: 'Email already exists' });
    }
    res.status(500).json({ message: 'Error creating user', error: err.message });
  }
});

// This api helps to read all users which stored in the server (GET request)
app.get('/api/users', async (req, res) => {
  try {
    const users = await User.find();
    res.json(users);
  } catch (err) {
    res.status(500).json({ message: 'Error retrieving users', error: err.message });
  }
});

//This api helps to read a single user (GET request)
app.get('/api/users/:id', async (req, res) => {
  try 
    {const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ message: 'User not found' });
    res.json(user);
  } catch (err) {
    res.status(500).json({ message: 'Error retrieving user', error: err.message });
  }
});

// This api helps to update user information(PUT request)
app.put('/api/users/:id', upload.single('profilePic'), async (req, res) => {
  try {
    // Fetch the existing user first
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ message: 'User not found' });

    // Processing the new values from the request body
    const { firstname, lastname, email } = req.body;

    // Prepare the update object
    const updatedData = {
      firstname: firstname || user.firstname,
      lastname: lastname || user.lastname,
      email: email || user.email,
      profilePic: req.file ? req.file.filename : user.profilePic,
    };

    // Update the user with the new data
    const updatedUser = await User.findByIdAndUpdate(req.params.id, updatedData, { new: true });

    // Show the user with updated information
    res.json(updatedUser);
  } catch (err) {
    res.status(500).json({ message: 'Error updating user', error: err.message });
  }
});


// This api helps to delete user from the server(DELETE request)
app.delete('/api/users/:id', async (req, res) => {
  try {
    const deletedUser = await User.findByIdAndDelete(req.params.id);
    if (!deletedUser) return res.status(404).json({ message: 'User not found' });
    res.json({ message: 'User deleted' });
  } catch (err) {
    res.status(500).json({ message: 'Error deleting user', error: err.message });
  }
});

// This code is used to start our Server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
